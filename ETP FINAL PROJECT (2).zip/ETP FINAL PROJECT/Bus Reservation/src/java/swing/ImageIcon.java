package java.swing;

public class ImageIcon {

}
