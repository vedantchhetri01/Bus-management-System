package shop2;

/**
 *
 * @author 
 */
public class Shop2 {

    /**
     * @param args 
     */
    public static void main(String[] args) {
    }
    
}
